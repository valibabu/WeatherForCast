//
//  NetworkManager.swift
//  WeatherAssistant
//
//  Created by Valibabu Shaik on 11/04/24.
//

import Foundation



enum APIError : Error {
    case badURL
    case noDataFound
    case modelDecodeError
    case responseError(error:String)
    case downloadError(error:DownloadError)
}


enum  DownloadError : Error {
    case badURL
    case unableToDownloadImage
    case modelDecodeError
    case responseError(error:String)
}


class NetworkManager {
    
    var apiHanlder: APIHanlderDelegate
    var responseHandler : ResponseHanlderDelegate
    
    init(apiHanlder: APIHanlderDelegate = APIHandler(), responseHandler: ResponseHanlderDelegate = ResponseHanlder()) {
        self.apiHanlder = apiHanlder
        self.responseHandler = responseHandler
    }
  
    //request:APIRequest<U>
    func makeService<T : Codable , U:EndPoint>(request: inout U, type:T.Type, completion:@escaping (Result<T, APIError>)-> Void) {
        self.apiHanlder.fetchResponse(request: &request) { result in
 
            switch result {
            case .success(let success):
                self.responseHandler.extractResponse(fetchedData: success, type: type) { modelResponse in
                    switch modelResponse {
                    case .success(let success):
                        completion(.success(success))
                    case .failure(let failure):
                        completion(.failure(failure))
                    }
                }
            case .failure(let failure):
                completion(.failure(failure))
            }
        }
        
    }
    
  
    
}




