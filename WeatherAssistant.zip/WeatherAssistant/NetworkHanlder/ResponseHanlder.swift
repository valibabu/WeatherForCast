//
//  ResponseHanlder.swift
//  WeatherAssistant
//
//  Created by Valibabu Shaik on 11/04/24.
//

import Foundation

protocol ResponseHanlderDelegate {
    func extractResponse<T: Codable>(fetchedData:Data, type:T.Type , completion:(Result<T, APIError>)-> Void) 
}

class ResponseHanlder : ResponseHanlderDelegate {
    
    func extractResponse<T:Codable>(fetchedData:Data, type:T.Type , completion:(Result<T, APIError>)-> Void) {
        do {
            let modelData = try JSONDecoder().decode(type.self, from: fetchedData)
            completion(.success(modelData))
        }
        catch {
            completion(.failure(.modelDecodeError))
        }
    }
}
