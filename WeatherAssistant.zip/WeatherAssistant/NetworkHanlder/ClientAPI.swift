//
//  API.swift
//  WeatherAssistant
//
//  Created by Valibabu Shaik on 11/04/24.
//

import Foundation


protocol EndPoint {
    associatedtype RequestType
    
    var path : String {get}
    var method : String {get}
    var body : Data? {get}
    var headers: [String : String]? {get}
    
    mutating func constructURL() -> URL?
    
}






