//
//  APIHandler.swift
//  WeatherAssistant
//
//  Created by Valibabu Shaik on 11/04/24.
//

import Foundation


protocol APIHanlderDelegate {
    func fetchResponse<U:EndPoint>(request:inout U, completion:@escaping (Result<Data , APIError>)->Void)
}


class APIHandler: APIHanlderDelegate {
   
    
    func fetchResponse<U:EndPoint>(request:inout U, completion:@escaping (Result<Data , APIError>)->Void) {
        guard let url = request.constructURL() else {return completion(.failure(.badURL))}
        
        var urlRequest  = URLRequest(url: url)
        if request.method == "POST" {
            urlRequest.httpMethod = request.method
            urlRequest.httpBody = request.body
            urlRequest.allHTTPHeaderFields = request.headers
        }
        
        URLSession.shared.dataTask(with: urlRequest) { data, response, error in
            guard let httpResponse = response as? HTTPURLResponse else {return completion(.failure(.noDataFound))}
            
            switch httpResponse.statusCode {
            case 200..<300:
                guard let dataResponse = data else {return completion(.failure(.noDataFound))}
                completion(.success(dataResponse))
            case 400..<500:
                completion(.failure(.responseError(error: "Client error")))
            case 500..<600:
                completion(.failure(.responseError(error: "Server error")))
            default:
                completion(.failure(.responseError(error: "Unknown Error")))
            }
        }.resume()
    }
}
