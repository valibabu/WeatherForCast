//
//  ContentView.swift
//  WeatherAssistant
//
//  Created by Valibabu Shaik on 11/04/24.
//

import SwiftUI
import UIKit


struct WeatherForecast: View {
    @StateObject var viewModel = WeatherViewModel()

    @State private var selection:String = "Telangana"
    
    var body: some View {
            ZStack(alignment:.top) {
                BackGroundView()
                VStack {
                    Text("Weather \(Text("ForeCasts").foregroundColor(.color15))")
                        .font(.title)
                        .foregroundStyle(.white)
                        .padding(.top , 30)
                        
                    Image(.cloud)
                        .resizable()
                        .frame(width: 120, height: 120, alignment: .center)
                    
                    SearchWeatherView(selection: $selection)
                        ZStack {
                            VStack {
                                WeatherDetails()
                            }
                        }
                        .frame(height: 220)
                        
                    SunriseAndUVIndex()
                            .padding()
                }
            }
           .onAppear(perform: {
            let selected = viewModel.country.filter{ $0.name == selection}
            viewModel.getWeatherDeatails(seclectedCity:selected.first)
           })
           .environmentObject(viewModel)
    }
}


struct BackGroundView : View {
    var body: some View {
        Image(.bg1)
          .resizable()
          .ignoresSafeArea()
      
        Color.black.opacity(0.55)
           .ignoresSafeArea()
    }
}

struct SearchWeatherView: View {
    @Binding var selection : String
    @EnvironmentObject var viewModel: WeatherViewModel
    
    
    var body: some View {
        
        RoundedRectangle(cornerRadius: 25.0)
            .fill(.white)
            .frame(width:300 , height: 50)
            .overlay {
                VStack {
                    Picker("", selection: $selection) {
                        ForEach(viewModel.country , id:\.name) { state in
                            Text(state.name).tag(state.name)
                        }
                    }
                    .onChange(of: selection, {
                        let selected = viewModel.country.filter{ $0.name == selection}
                        viewModel.getWeatherDeatails(seclectedCity:selected.first)
                    })
                }
            }
    }
}


struct WeatherDetails : View {
    @EnvironmentObject var viewModel: WeatherViewModel
    var body: some View {
        RoundedRectangle(cornerRadius: 15.0)
            .fill(.black.opacity(0.55))
            .overlay(alignment:.top) {
                VStack {
                    HStack(alignment:.top) {
                        if let minTemp  = viewModel.dayWeatherDetail?.daily.temperature2mMin.first , let unit = viewModel.dayWeatherDetail?.dailyUnits.temperature2mMin {
                            Text("MIN: \(Int(Double(minTemp).rounded())) \(unit)")
                                .font(.system(size: 18))
                                .fontWeight(.semibold)
                                .foregroundStyle(.white)
                                .padding([.top, .leading])
                        }
                        
                        Spacer()
                        
                        Text("\(Date().toLocalDateString())")
                            .font(.system(size: 18))
                            .fontWeight(.bold)
                            .foregroundStyle(.white)
                            .padding([.top, .leading])
                        Spacer()
                        if let maxTemp  = viewModel.dayWeatherDetail?.daily.temperature2mMax.first , let unit = viewModel.dayWeatherDetail?.dailyUnits.temperature2mMax {
                            Text("MAX: \(Int(Double(maxTemp).rounded())) \(unit)")
                                .font(.system(size: 18))
                                .fontWeight(.semibold)
                                .foregroundStyle(.white)
                                .padding([.top, .trailing])
                        }
                       
                    }
                    WeatherTimeSlots()
                        .padding([.leading , .trailing] , 8)
                }
            }
    }
}


struct WeatherTimeSlots : View {
    @EnvironmentObject var viewModel: WeatherViewModel
    
    var body: some View {
        ScrollView(.horizontal , showsIndicators: false) {
            HStack {
                if let times = viewModel.dayWeatherDetail?.hourly.time, let temparature = viewModel.dayWeatherDetail?.hourly.temperature_2m , let unit = viewModel.dayWeatherDetail?.dailyUnits.temperature2mMax ,  times.count == temparature.count  {
                    
                    ForEach( Array(zip(times, temparature)) , id: \.0) { time , temparature in
                        WeatherItem(time: time, temparature: "\(Int(temparature.rounded())) \(unit)")
                            .padding([.top , .bottom])
                    }
                }
                
            }
        }
        
    }
}


struct WeatherItem : View {
    var time : String
    var temparature: String
    
    var body: some View {
        Capsule()
            .fill(
                Color.black.opacity(0.3)
            )
            .frame(width: 62, height: 142)
            .overlay {
                VStack {
                    Text("\(temparature)")
                        .foregroundStyle(.white)
                    Image(.cloud)
                        .resizable()
                        .frame(width: 46, height: 46, alignment: .center)
                    Text(time.timeLaps())
                        .foregroundStyle(.white)
                }
            }
    }
}


struct SunriseAndUVIndex : View {
    @EnvironmentObject  var viewModel : WeatherViewModel
    var body: some View {
        HStack {
            SunriseView()
            Spacer()
            UVIndexView()
        }
    }
}


struct SunriseView:View {
    
    @EnvironmentObject  var viewModel : WeatherViewModel
    
    var body: some View {
        RoundedRectangle(cornerRadius: 25.0)
            .fill(.black.opacity(0.6))
            .frame(width: 150, height: 150)
            .overlay(alignment:.top) {
                VStack {
                    HStack {
                        Image(.star)
                            .renderingMode(.template)
                            .resizable()
                            .foregroundColor(.white)
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 30, height: 30)
                        
                        Text("SUNRISE")
                            .font(.system(size: 14))
                            .foregroundStyle(.white)
                        
                        Spacer()
                    }.padding(.leading)
                    Spacer()
                    Text(viewModel.dayWeatherDetail?.daily.sunrise.first?.timeLapsAMorPM() ?? "N/A")
                        .foregroundStyle(.white)
                        .font(.title)
                    Spacer()
                    Text("Sunset: \(viewModel.dayWeatherDetail?.daily.sunset.first?.timeLapsAMorPM() ?? "N/A")")
                        .font(.system(size: 14))
                        .foregroundStyle(.white)
                    Spacer()
                }
            }
            .toolbar(.hidden, for: .navigationBar)
    }
}


struct UVIndexView : View {
    @EnvironmentObject var viewModel : WeatherViewModel
    
    var body: some View {
        RoundedRectangle(cornerRadius: 25.0)
            .fill(.black.opacity(0.6))
            .frame(width: 150, height: 150)
            .overlay(alignment:.top) {
                VStack {
                    HStack {
                        Image(.star)
                            .renderingMode(.template)
                            .resizable()
                            .foregroundColor(.white)
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 30, height: 30)
                        
                        
                        Text("UV INDEX")
                            .font(.system(size: 14))
                            .foregroundStyle(.white)
                        Spacer()
                    }
                    .padding(.leading)
                    Spacer()
                    Text("\(Int(viewModel.dayWeatherDetail?.daily.uvIndexMax.first ?? 0))")
                        .foregroundStyle(.white)
                        .font(.title)
                    Spacer()
                    Text("Max")
                        .font(.caption)
                        .foregroundStyle(.white)
                    Spacer()
                    
                }
                
            }
    }
}

#Preview {
    WeatherForecast()
        .environmentObject(WeatherViewModel())
      
}


