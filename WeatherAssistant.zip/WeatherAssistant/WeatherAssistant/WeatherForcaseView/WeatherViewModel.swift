//
//  WeatherViewModel.swift
//  WeatherAssistant
//
//  Created by Valibabu Shaik on 14/04/24.
//

import Foundation

struct CountryCoord {
    
    var name: String
    
    struct Coordinates  {
        
        var latitude : Double
        var longitude : Double
        
    }
    
    var coordinates : Coordinates
}


class WeatherViewModel : ObservableObject {
    
    var weatherService : WeatherAPIServiceDelegate
    var hourBasisTemparature : Hourly?
    
    
   @Published var dayWeatherDetail : OneDayWeatherModel?
    
    var country : [CountryCoord] = [CountryCoord(name: "Telangana", coordinates: .init(latitude: 17.1232, longitude:  79.2088)),
                                    CountryCoord(name: "Andhra Pradesh", coordinates: .init(latitude:15.9129, longitude: 79.7400)),
                                    CountryCoord(name: "Kerala", coordinates: .init(latitude: 10.8505, longitude: 76.2711)),
                                    CountryCoord(name: "Karnataka", coordinates: .init(latitude: 15.3173, longitude: 75.7139)),
                                    CountryCoord(name: "Delhi", coordinates: .init(latitude: 28.7041, longitude: 77.1025))]
    
    init(weatherService: WeatherAPIServiceDelegate = WeatherAPIService()) {
        self.weatherService = weatherService
        
        
    }
    
    func getWeatherDeatails(seclectedCity:CountryCoord?) {
        
        self.weatherService.getWetherInformation(request: .oneDayWeather(DayWeather(coordinates: seclectedCity ?? country[0])), type: OneDayWeatherModel.self) { result in
            switch result {
                
            case .success(let weather):
                print(weather)
                DispatchQueue.main.async {
                    self.dayWeatherDetail = weather
                    
                }
                
            case .failure(let failure):
                print(failure)
            }
        }
    }
    
    
}
