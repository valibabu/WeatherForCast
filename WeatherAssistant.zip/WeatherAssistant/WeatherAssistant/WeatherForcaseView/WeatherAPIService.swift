//
//  WeatherAPIService.swift
//  WeatherAssistant
//
//  Created by Valibabu Shaik on 13/04/24.
//

import SwiftUI
import Foundation


enum APIRequest<T> {
    case oneDayWeather(T)
    case weatherHistory(T)
}


struct WeatherRequestParams {
    
    var latitude : Double
    var longitude : Double
    var daily:[String]
    var start_date : String
    var end_date : String
    var timezone : String
    var hourly : String

    init(latitude:Double = 17.5, longitude:Double = 78.25) {
        self.latitude =  latitude
        self.longitude = longitude
        self.daily = ["sunrise", "sunset", "uv_index_max", "temperature_2m_max", "temperature_2m_min"]
        self.start_date = Date().currentDate()
        self.end_date = Date().currentDate()
        self.timezone = "IST"
        self.hourly = "temperature_2m"
    }
    
}


struct DayWeather  : EndPoint {
    
    typealias RequestType = WeatherRequestParams
    
    var path: String = "https://api.open-meteo.com/v1/forecast"
    
    var method: String = "GET"
    
    var body: Data?
    
    var headers: [String : String]?
    
    var coordinates : CountryCoord
    
    init(coordinates:CountryCoord) {
        self.coordinates = coordinates
    }
    
    
    mutating func constructURL() -> URL? {
        guard let url = URL(string: path) else {return nil}
        var urlComponents =  URLComponents(url: url, resolvingAgainstBaseURL: false)
        var urlQueryItems = [URLQueryItem]()
        let modelMirror = Mirror(reflecting: RequestType(latitude: coordinates.coordinates.latitude, longitude: coordinates.coordinates.longitude))
            
            
        for case let (key?, value) in modelMirror.children {
            switch value {
            case let intValue as Int:
                urlQueryItems.append(URLQueryItem(name: key, value: String(intValue)))
            case let doubleValue as Double:
                urlQueryItems.append(URLQueryItem(name: key, value: String(doubleValue)))
            case let stringValue as String:
                urlQueryItems.append(URLQueryItem(name: key, value: stringValue))
            case let arrayValue as [String]:
                let allValues = arrayValue.joined(separator: ",")
                urlQueryItems.append(URLQueryItem(name: key, value: allValues))
                
            default:
                print("Unsupported value type for key \(key)")
            }
        }
        urlComponents?.queryItems = urlQueryItems
        return urlComponents?.url
    }
}


protocol WeatherAPIServiceDelegate {
    func getWetherInformation<T:Codable , U:EndPoint>(request: APIRequest<U>, type:T.Type, completionHanlder:@escaping(Result<T, APIError>)->Void)
}


class WeatherAPIService : WeatherAPIServiceDelegate  {
    
    func getWetherInformation<T:Codable , U:EndPoint>(request: APIRequest<U>, type:T.Type, completionHanlder:@escaping(Result<T, APIError>)->Void) {
        //MARK: -  Just in case i wrote it , feel free to modify this , by passing different END POINTS to the request Params , i just tried to  -  it's @Vali
        /**
            This is not following SOLID Priciple but  just thought it might helpful in future,  but i am also not satified to this , may be i will change it later
         */
        
        switch request {
        case .oneDayWeather(var endPoint): // GET
            NetworkManager().makeService(request: &endPoint, type:type, completion: completionHanlder)
        case .weatherHistory(var endPoint): // GET or POST ANY
            NetworkManager().makeService(request: &endPoint, type:type, completion: completionHanlder)
        }
    }
    
}
