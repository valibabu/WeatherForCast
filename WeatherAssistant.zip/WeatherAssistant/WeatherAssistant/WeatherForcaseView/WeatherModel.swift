//
//  WeatherModel.swift
//  WeatherAssistant
//
//  Created by Valibabu Shaik on 13/04/24.
//

import Foundation



struct OneDayWeatherModel: Codable {
    let daily: DailyData
    let dailyUnits: DailyUnits
    let elevation: Double
    let latitude: Double
    let longitude: Double
    let hourly : Hourly


    private enum CodingKeys: String, CodingKey {
         case daily = "daily"
         case dailyUnits = "daily_units"
         case elevation = "elevation"
         case latitude = "latitude"
         case longitude = "longitude"
         case hourly = "hourly"
 
    }
}

struct Hourly  : Codable , Hashable {
    var time : [String]
    var temperature_2m : [Double]
}


struct DailyData: Codable {
    let sunrise: [String]
    let sunset: [String]
    let time: [String]
    let temperature2mMax: [Double]
    let temperature2mMin: [Double]
    let uvIndexMax: [Double]

    private enum CodingKeys: String, CodingKey {
        case sunrise = "sunrise"
        case sunset = "sunset"
        case time = "time"
        case temperature2mMax = "temperature_2m_max"
        case temperature2mMin = "temperature_2m_min"
        case uvIndexMax = "uv_index_max"
    }
}

struct DailyUnits: Codable {
    
    let sunrise: String
    let sunset: String
    let temperature2mMax: String
    let temperature2mMin: String
    let time: String
    let uvIndexMax: String

    private enum CodingKeys: String, CodingKey {
        case sunrise, sunset, time
        case temperature2mMax = "temperature_2m_max"
        case temperature2mMin = "temperature_2m_min"
        case uvIndexMax = "uv_index_max"
    }
}


