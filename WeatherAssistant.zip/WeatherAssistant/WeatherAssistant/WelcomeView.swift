//
//  WelcomeView.swift
//  WeatherAssistant
//
//  Created by Valibabu Shaik on 12/04/24.
//

import SwiftUI

struct WelcomeView: View {
    
    var body: some View {
        ZStack { 
            BackGroundColors()
            IntroView()
            
        }
    }
}


struct BackGroundColors:View {
    
    var body: some View {
        LinearGradient(colors: [.color5,.color19 , .color21], startPoint: .top, endPoint: .bottom)
            .ignoresSafeArea()
            
        Color(.black).opacity(0.3)
            .ignoresSafeArea()
    }
}

struct IntroView:View {
    
    
    var body: some View {
        VStack {
            Image(.cloud)
                .resizable()
                .aspectRatio(contentMode: .fit)
            Spacer()
            
            Text("Weather \(Text("ForeCasts").foregroundColor(.color15))")
                .font(.system(size: 45))
                .foregroundStyle(.white)
               Spacer()
                NavigationLink(destination: WeatherForecast()){
                    RoundedRectangle(cornerRadius: 25.0)
                        .fill(.color15)
                        .frame(width: 200, height: 50, alignment: .center)
                        .overlay {
                            Text("GET STARTED")
                                .font(.system(size: 18))
                                .foregroundColor(.white)
                        }
                }
            Spacer()
        }
        .toolbar(.hidden)
        
    }
}


#Preview {
    WelcomeView()
}
