//
//  WeatherAssistantApp.swift
//  WeatherAssistant
//
//  Created by Valibabu Shaik on 11/04/24.
//

import SwiftUI

@main
struct WeatherAssistantApp: App {
    var body: some Scene {
        WindowGroup {
            NavigationView {
                WelcomeView()
            }
            
        }
    }
}
