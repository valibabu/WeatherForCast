//
//  extensions.swift
//  WeatherAssistant
//
//  Created by Valibabu Shaik on 14/04/24.
//

import Foundation

// TODO: - Need to change names and make propery optimisations 

extension Date {
    static func fromISO8601String(_ iso8601String: String) -> Date? {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm"
        dateFormatter.timeZone = TimeZone(identifier: "UTC")
        return dateFormatter.date(from: iso8601String)
    }
    
    func toLocalTimeString() -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.timeZone = TimeZone.current
        dateFormatter.dateFormat = "HH:mm"//"hh:mm a" //"yyyy-MM-dd HH:mm"
        return dateFormatter.string(from: self)
    }
    
    func toLocalDateString() -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.timeZone = TimeZone.current
        dateFormatter.dateFormat = "MMMM d"
        return dateFormatter.string(from: self)
    }
    func toLocalTimeStringAMorPM() -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.timeZone = TimeZone(identifier: "UTC")
        dateFormatter.dateFormat = "hh:mm a" //"yyyy-MM-dd HH:mm"
        return dateFormatter.string(from: self)
    }
}


extension String {
    
    func timeLaps() -> String {
        if let date = Date.fromISO8601String(self) {
            let localTimeString = date.toLocalTimeString()
            return localTimeString
        } else {
            return "N/A"
        }
    }
    
    func timeLapsAMorPM() -> String {
        if let date = Date.fromISO8601String(self) {
            let localTimeString = date.toLocalTimeStringAMorPM()
            return localTimeString
        } else {
            return "N/A"
        }
    }
}
